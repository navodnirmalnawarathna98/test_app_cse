package com.example.luxevistaresort;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;
import android.content.Intent;

import java.util.List;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.ServiceViewHolder> {
    private Context context;
    private List<Service> serviceList;

    public ServiceAdapter(Context context, List<Service> serviceList) {
        this.context = context;
        this.serviceList = serviceList;
    }

    @NonNull
    @Override
    public ServiceAdapter.ServiceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.service_item, parent, false);
        return new ServiceAdapter.ServiceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ServiceAdapter.ServiceViewHolder holder, int position) {
        Service service = serviceList.get(position);
        holder.serviceType.setText(service.getServiceType());
        holder.serviceDescription.setText(service.getDescription());
        holder.servicePrice.setText("Price: $" + service.getPrice());

//        Picasso.get().load(room.getImageUrl()).into(holder.roomImage);

        String photourl = service.getPhotourl();
        if (photourl != null && !photourl.isEmpty()) {
            Picasso.get().load(photourl).into(holder.serviceImage);
        } else {
            // Set a placeholder image or hide the ImageView if no image URL is provided
            holder.serviceImage.setImageResource(R.drawable.placeholder_image);
        }
        // Set click listener for the item
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ServiceDetailsActivity.class);
            intent.putExtra("serviceType", service.getServiceType());
            intent.putExtra("description", service.getDescription());
            intent.putExtra("photourl", service.getPhotourl());
            intent.putExtra("price", service.getPrice());

            intent.putExtra("documentId", service.getDocumentId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return serviceList.size();
    }

    public static class ServiceViewHolder extends RecyclerView.ViewHolder {
        TextView serviceType, serviceDescription, servicePrice ;
        ImageView serviceImage;

        public ServiceViewHolder(@NonNull View itemView) {
            super(itemView);
            serviceType = itemView.findViewById(R.id.serviceType);
            serviceDescription = itemView.findViewById(R.id.serviceDescription);
            servicePrice = itemView.findViewById(R.id.servicePrice);
            serviceImage = itemView.findViewById(R.id.serviceImage);
        }
    }

}
