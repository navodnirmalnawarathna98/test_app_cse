package com.example.luxevistaresort;

public class Service {

    private String serviceType, description, photourl , documentId;
    private int price;


    public Service() {
        // Default constructor for Firestore
    }

    public Service(String serviceType, String description, String photourl, int price) {
        this.serviceType = serviceType;
        this.description = description;

        this.photourl = photourl;
        this.price = price;


    }

    // Getters and setters
    public String getServiceType() {
        return serviceType;
    }

    public String getDescription() {
        return description;
    }



    public String getPhotourl() {
        return photourl;
    }

    public int getPrice() {
        return price;
    }



    public String getDocumentId() {
        return documentId;
    }
    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
}
