package com.example.luxevistaresort;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private NotificationsAdapter adapter;
    private List<Notification> notificationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.notifications);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.notificationsRecyclerView);


        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        notificationList = new ArrayList<>();


        notificationList.add(new Notification("Special Offer", "Get 20% off on your next booking!"));
        notificationList.add(new Notification("Event Update", "Join us for the Summer Beach Party on Saturday!"));
        notificationList.add(new Notification("Service Update", "The spa will be closed for maintenance tomorrow."));


        adapter = new NotificationsAdapter(notificationList, this);
        recyclerView.setAdapter(adapter);
    }
}