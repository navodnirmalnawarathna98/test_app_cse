package com.example.luxevistaresort;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class ProfileActivity extends AppCompatActivity {
    // UI components
    private TextView profileName, profileEmail, profileContact, profileCountry, profilePreferences, profileTravelDates;
    private ImageView profileImage;
    private Button logoutButton;

    private EditText editPreferences, editTravelDates;
    private Button saveProfileBtn;


    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.profile);


        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        profileName = findViewById(R.id.profileName);
        profileEmail = findViewById(R.id.profileEmail);
        profileContact = findViewById(R.id.profileContact);
        profileCountry = findViewById(R.id.profileCountry);
        profilePreferences = findViewById(R.id.profilePreferences);
        profileTravelDates = findViewById(R.id.profileTravelDates);
        profileImage = findViewById(R.id.profileImage);
        logoutButton = findViewById(R.id.logoutButton);

        editPreferences = findViewById(R.id.editPreferences);
        editTravelDates = findViewById(R.id.editTravelDates);
        saveProfileBtn = findViewById(R.id.saveProfileBtn);


        fetchUserProfile();


        logoutButton.setOnClickListener(v -> logoutUser());


        saveProfileBtn.setOnClickListener(v -> saveUserProfile());
    }

    private void fetchUserProfile() {
        String userId = mAuth.getCurrentUser().getUid();  // Get the current user's ID


        db.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {

                        profileName.setText(documentSnapshot.getString("name"));
                        profileEmail.setText(documentSnapshot.getString("email"));
                        profileContact.setText(documentSnapshot.getString("contact"));
                        profileCountry.setText(documentSnapshot.getString("country"));
                        profilePreferences.setText(documentSnapshot.getString("preferences"));
                        profileTravelDates.setText(documentSnapshot.getString("travelDates"));


                        editPreferences.setText(documentSnapshot.getString("preferences"));
                        editTravelDates.setText(documentSnapshot.getString("travelDates"));
                    } else {
                        Toast.makeText(ProfileActivity.this, "User data not found.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(ProfileActivity.this, "Failed to fetch user data: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void saveUserProfile() {
        String userId = mAuth.getCurrentUser().getUid();  // Get current user ID

        // Get updated preferences and travel dates from the EditTexts
        String updatedPreferences = editPreferences.getText().toString().trim();
        String updatedTravelDates = editTravelDates.getText().toString().trim();

        if (updatedPreferences.isEmpty() || updatedTravelDates.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update the user's data in Firestore
        db.collection("users").document(userId)
                .update("preferences", updatedPreferences, "travelDates", updatedTravelDates)
                .addOnSuccessListener(aVoid -> {
                    // Update the profile view with new data
                    profilePreferences.setText(updatedPreferences);
                    profileTravelDates.setText(updatedTravelDates);
                    Toast.makeText(ProfileActivity.this, "Profile updated successfully.", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(ProfileActivity.this, "Error updating profile: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void logoutUser() {
        // Log out the user and redirect to the login screen
        mAuth.signOut();
        finish();  // Close this activity
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}