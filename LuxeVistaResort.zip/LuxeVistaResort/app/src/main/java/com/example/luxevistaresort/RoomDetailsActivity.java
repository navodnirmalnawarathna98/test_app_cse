package com.example.luxevistaresort;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import android.app.DatePickerDialog;
import android.content.Intent;

import com.google.firebase.firestore.FirebaseFirestore;

public class RoomDetailsActivity extends AppCompatActivity {

    private ImageView roomDetailImage;
    private TextView roomDetailName, roomDetailDescription, roomDetailPrice, roomAvailability , selectedDateText;
    private Button roomBookingButton, selectDateButton;
    private FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.room_details);

        db = FirebaseFirestore.getInstance();

        // Initialize UI components
        roomDetailImage = findViewById(R.id.roomDetailImage);
        roomDetailName = findViewById(R.id.roomDetailName);
        roomDetailDescription = findViewById(R.id.roomDetailDescription);
        roomDetailPrice = findViewById(R.id.roomDetailPrice);
        roomBookingButton = findViewById(R.id.roomBookingButton);
        roomAvailability = findViewById(R.id.roomAvailability);
        selectDateButton = findViewById(R.id.selectDateButton);
        selectedDateText = findViewById(R.id.selectedDateText);

        // Get data passed from the RecyclerView
        String name = getIntent().getStringExtra("name");
        String description = getIntent().getStringExtra("description");
        String imageUrl = getIntent().getStringExtra("imageUrl");
        int price = getIntent().getIntExtra("price", 0);
        boolean availability = getIntent().getBooleanExtra("availability",true);
        String documentId = getIntent().getStringExtra("documentId");

        // Set data to UI components
        roomDetailName.setText(name);
        roomDetailDescription.setText(description);
        roomDetailPrice.setText("Price: $" + price + "/night");
        if(availability) {
            roomAvailability.setText("Room is available");
        }else {
            roomAvailability.setText("Room already reserved");
        }

        if (imageUrl != null && !imageUrl.isEmpty()) {
            Picasso.get().load(imageUrl).into(roomDetailImage);
        } else {
            roomDetailImage.setImageResource(R.drawable.placeholder_image);
        }

        // Handle the "Select Booking Date" button click
        selectDateButton.setOnClickListener(v -> showDatePicker());

        // Handle booking button click
        roomBookingButton.setOnClickListener(v -> {
            // Add booking logic here
            Toast.makeText(RoomDetailsActivity.this, documentId , Toast.LENGTH_SHORT).show();

            String selectedDate = selectedDateText.getText().toString();
            if (selectedDate.equals("No date selected")) {
                // Show a message if no date is selected
                selectedDateText.setError("Please select a booking date!");
                return;
            }
            // Handle booking logic here (e.g., save to Firestore)
            Toast.makeText(RoomDetailsActivity.this, documentId , Toast.LENGTH_SHORT).show();

            String name1 = "testing"; // Replace with actual user's name or ID
            String bookingPath = "rooms/" + documentId + "/booking"; // Path to the booking collection

// Booking logic
            Map<String, Object> booking = new HashMap<>();
            booking.put("bookedby", name1);

// Check if the selected date already exists as a document ID
            db.collection(bookingPath).document(selectedDate)
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            // If the document already exists, show an error
                            Toast.makeText(RoomDetailsActivity.this, "This date is already booked!", Toast.LENGTH_SHORT).show();
                        } else {
                            // Save booking if the document doesn't exist
                            db.collection(bookingPath).document(selectedDate)
                                    .set(booking)
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(RoomDetailsActivity.this, "Booking successful!", Toast.LENGTH_SHORT).show();
                                        // Navigate to MainPageActivity
                                        Intent intent = new Intent(RoomDetailsActivity.this, MainPageActivity.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(intent);
                                        finish();
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(RoomDetailsActivity.this, "Failed to book: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    });
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(RoomDetailsActivity.this, "Error checking booking: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });



        });
    }

    private void showDatePicker() {
        // Get the current date
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Create a DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    // Format and display the selected date
                    String formattedDate = selectedDay + "-" + (selectedMonth + 1) + "-" + selectedYear;
                    selectedDateText.setText(formattedDate);
                }, year, month, day);

        // Show the DatePickerDialog
        datePickerDialog.show();
    }
}