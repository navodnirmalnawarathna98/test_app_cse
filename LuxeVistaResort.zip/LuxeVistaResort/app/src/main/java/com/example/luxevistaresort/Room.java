package com.example.luxevistaresort;

public class Room {
    private String name, description, type, imageUrl , documentId;
    private int price;
    private boolean availability;

    public Room() {

    }

    public Room(String name, String description, String type, String imageUrl, int price, boolean availability) {
        this.name = name;
        this.description = description;
        this.type = type;
        this.imageUrl = imageUrl;
        this.price = price;
        this.availability = availability;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getType() {
        return type;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public int getPrice() {
        return price;
    }

    public boolean isAvailability() {
        return availability;
    }

    public String getDocumentId() {
        return documentId;
    }
    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

}
