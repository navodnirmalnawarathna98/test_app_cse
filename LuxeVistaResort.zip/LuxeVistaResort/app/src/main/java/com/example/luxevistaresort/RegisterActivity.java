package com.example.luxevistaresort;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


public class RegisterActivity extends AppCompatActivity {


    private FirebaseAuth mAuth;
    private FirebaseFirestore db;


    private EditText signupName, signupEmail, signupPassword, signupCountry, signupContact, signupPreferences, signupTravelDates;
    private Button signupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.register);


        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();


        signupName = findViewById(R.id.signupName);
        signupEmail = findViewById(R.id.signupEmail);
        signupPassword = findViewById(R.id.signupPassword);
        signupCountry = findViewById(R.id.signupCountry);
        signupContact = findViewById(R.id.signupContact);
        signupPreferences = findViewById(R.id.signupPreferences);
        signupTravelDates = findViewById(R.id.signupTravelDates);
        signupButton = findViewById(R.id.signupbtn);


        signupButton.setOnClickListener(v -> registerUser());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    private void registerUser() {

        String name = signupName.getText().toString().trim();
        String email = signupEmail.getText().toString().trim();
        String password = signupPassword.getText().toString().trim();
        String country = signupCountry.getText().toString().trim();
        String contact = signupContact.getText().toString().trim();
        String preferences = signupPreferences.getText().toString().trim();
        String travelDates = signupTravelDates.getText().toString().trim();


        if (TextUtils.isEmpty(name)) {
            signupName.setError("Name is required");
            return;
        }
        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            signupEmail.setError("Valid email is required");
            return;
        }
        if (TextUtils.isEmpty(password) || password.length() < 6) {
            signupPassword.setError("Password must be at least 6 characters");
            return;
        }
        if (TextUtils.isEmpty(country)) {
            signupCountry.setError("Country is required");
            return;
        }
        if (TextUtils.isEmpty(contact)) {
            signupContact.setError("Contact number is required");
            return;
        }
        if (TextUtils.isEmpty(preferences)) {
            signupPreferences.setError("Preferences are required");
            return;
        }
        if (TextUtils.isEmpty(travelDates)) {
            signupTravelDates.setError("Travel dates are required");
            return;
        }


        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {

                        String userId = mAuth.getCurrentUser().getUid();


                        Map<String, Object> user = new HashMap<>();
                        user.put("name", name);
                        user.put("email", email);
                        user.put("country", country);
                        user.put("contact", contact);
                        user.put("preferences", preferences);
                        user.put("travelDates", travelDates);


                        db.collection("users").document(userId)
                                .set(user)
                                .addOnSuccessListener(aVoid -> {

                                    Toast.makeText(RegisterActivity.this, "User registered successfully!", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(this, LoginActivity.class);
                                    startActivity(intent);
                                })
                                .addOnFailureListener(e -> {

                                    Toast.makeText(RegisterActivity.this, "Failed to save user details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    } else {

                        Toast.makeText(RegisterActivity.this, "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


}