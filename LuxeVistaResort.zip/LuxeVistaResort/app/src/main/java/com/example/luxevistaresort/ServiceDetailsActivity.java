package com.example.luxevistaresort;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import android.app.DatePickerDialog;

import com.google.firebase.firestore.FirebaseFirestore;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class ServiceDetailsActivity extends AppCompatActivity {

    private ImageView serviceDetailImage;
    private TextView serviceDetailType, serviceDetailDescription, serviceDetailPrice , selectedDateText;
    private Button serviceBookingButton, selectDateButton;
    private FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.service_details);

        db = FirebaseFirestore.getInstance();

        // Initialize UI components
        serviceDetailImage = findViewById(R.id.serviceDetailImage);
        serviceDetailType = findViewById(R.id.serviceDetailType);
        serviceDetailDescription = findViewById(R.id.serviceDetailDescription);
        serviceDetailPrice = findViewById(R.id.serviceDetailPrice);
        serviceBookingButton = findViewById(R.id.serviceBookingButton);
        selectDateButton = findViewById(R.id.serviceSelectDateButton);
        selectedDateText = findViewById(R.id.serviceSelectedDateText);

        // Get data passed from the RecyclerView
        String serviceType = getIntent().getStringExtra("serviceType");
        String description = getIntent().getStringExtra("description");
        String imageUrl = getIntent().getStringExtra("photourl");
        int price = getIntent().getIntExtra("price", 0);
        String documentId = getIntent().getStringExtra("documentId");

        // Set data to UI components
        serviceDetailType.setText(serviceType);
        serviceDetailDescription.setText(description);
        serviceDetailPrice.setText("Price: $" + price );


        if (imageUrl != null && !imageUrl.isEmpty()) {
            Picasso.get().load(imageUrl).into(serviceDetailImage);
        } else {
            serviceDetailImage.setImageResource(R.drawable.placeholder_image);
        }

        // Handle the "Select Booking Date" button click
        selectDateButton.setOnClickListener(v -> showDatePicker());

        // Handle booking button click
        serviceBookingButton.setOnClickListener(v -> {
            // Add booking logic here
            Toast.makeText(ServiceDetailsActivity.this, documentId , Toast.LENGTH_SHORT).show();

            String selectedDate = selectedDateText.getText().toString();
            if (selectedDate.equals("No date selected")) {
                // Show a message if no date is selected
                selectedDateText.setError("Please select a booking date!");
                return;
            }
            // Handle booking logic here (e.g., save to Firestore)
            Toast.makeText(ServiceDetailsActivity.this, documentId , Toast.LENGTH_SHORT).show();

            String name1 = "testing"; // Replace with actual user's name or ID
            String bookingPath = "services/" + documentId + "/booking"; // Path to the booking collection

// Booking logic
            Map<String, Object> booking = new HashMap<>();
            booking.put("bookedby", name1);

// Check if the selected date already exists as a document ID
            db.collection(bookingPath).document(selectedDate)
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            // If the document already exists, show an error
                            Toast.makeText(ServiceDetailsActivity.this, "This date is already booked!", Toast.LENGTH_SHORT).show();
                        } else {
                            // Save booking if the document doesn't exist
                            db.collection(bookingPath).document(selectedDate)
                                    .set(booking)
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(ServiceDetailsActivity.this, "Booking successful!", Toast.LENGTH_SHORT).show();
                                        // Navigate to MainPageActivity
                                        Intent intent = new Intent(ServiceDetailsActivity.this, MainPageActivity.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(intent);
                                        finish();
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(ServiceDetailsActivity.this, "Failed to book: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    });
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(ServiceDetailsActivity.this, "Error checking booking: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });



        });
    }

    private void showDatePicker() {
        // Get the current date
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Create a DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    // Format and display the selected date
                    String formattedDate = selectedDay + "-" + (selectedMonth + 1) + "-" + selectedYear;
                    selectedDateText.setText(formattedDate);
                }, year, month, day);

        // Show the DatePickerDialog
        datePickerDialog.show();
    }
}