package com.example.luxevistaresort;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class ServicebookActivity extends AppCompatActivity {

    private RecyclerView serviceRecyclerView;
    private ServiceAdapter serviceAdapter;
    private List<Service> serviceList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.servicebook);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Firestore and UI components
        db = FirebaseFirestore.getInstance();
        serviceRecyclerView = findViewById(R.id.serviceRecyclerView);
        serviceRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        serviceList = new ArrayList<>();
        serviceAdapter = new ServiceAdapter(this, serviceList);
        serviceRecyclerView.setAdapter(serviceAdapter);

        // Fetch room data from Firestore
        fetchServices();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void fetchServices() {
        db.collection("services")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        serviceList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Service service = document.toObject(Service.class);
                            // Set the document ID in the Room object
                            service.setDocumentId(document.getId());
                            serviceList.add(service);
                            Log.d("Firestore", "Service Type: " + service.getServiceType());
                            Log.d("Firestore", "Service Url: " + service.getPhotourl());
                            Log.d("Firestore", "Service Description: " + service.getDescription());
                        }
                        serviceAdapter.notifyDataSetChanged();
                    } else {
                        Log.d("Firestore", "Error getting documents: ", task.getException());
                    }
                })
                .addOnFailureListener(e -> {
                    Log.d("Firestore", "Error fetching rooms", e);
                });
    }
}