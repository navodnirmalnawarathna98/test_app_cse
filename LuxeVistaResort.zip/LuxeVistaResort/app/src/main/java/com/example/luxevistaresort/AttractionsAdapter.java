package com.example.luxevistaresort;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.squareup.picasso.Picasso;

import java.util.List;

public class AttractionsAdapter extends RecyclerView.Adapter<AttractionsAdapter.AttractionViewHolder> {

    private List<Attraction> attractionList;
    private Context context;

    public AttractionsAdapter(List<Attraction> attractionList, Context context) {
        this.attractionList = attractionList;
        this.context = context;
    }

    @Override
    public AttractionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.attraction_item, parent, false);
        return new AttractionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AttractionViewHolder holder, int position) {
        Attraction attraction = attractionList.get(position);
        holder.attractionName.setText(attraction.getName());
        holder.attractionDescription.setText(attraction.getDescription());
        holder.attractionPrice.setText("Price: $" + attraction.getPrice());


        Picasso.get()
                .load(attraction.getImageUrl())
                .into(holder.attractionImage);
    }

    @Override
    public int getItemCount() {
        return attractionList.size();
    }

    public static class AttractionViewHolder extends RecyclerView.ViewHolder {
        TextView attractionName, attractionDescription, attractionPrice;
        ImageView attractionImage;

        public AttractionViewHolder(View itemView) {
            super(itemView);
            attractionName = itemView.findViewById(R.id.attractionName);
            attractionDescription = itemView.findViewById(R.id.attractionDescription);
            attractionPrice = itemView.findViewById(R.id.attractionPrice);
            attractionImage = itemView.findViewById(R.id.attractionImage);
        }
    }
}
