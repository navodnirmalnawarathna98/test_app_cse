package com.example.luxevistaresort;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.main_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        findViewById(R.id.roomBookingSection).setOnClickListener(v -> openRoomBooking());

        findViewById(R.id.profileSection).setOnClickListener(v -> openProfile());

        findViewById(R.id.attractionsSection).setOnClickListener(v -> openAttractions());

        findViewById(R.id.notificationsSection).setOnClickListener(v -> openNotification());

        findViewById(R.id.serviceReservationSection).setOnClickListener(v -> openServiceBooking());

        Button logoutButton = findViewById(R.id.logoutButton);
        logoutButton.setOnClickListener(v -> logout());
    }

    private void openRoomBooking() {
        Intent intent = new Intent(this, RoombookActivity.class);
        startActivity(intent);
    }

    private void openProfile() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }

    private void openAttractions() {
        Intent intent = new Intent(this, AttractionActivity.class);
        startActivity(intent);
    }

    private void openNotification() {
        Intent intent = new Intent(this, NotificationsActivity.class);
        startActivity(intent);
    }

    private void openServiceBooking() {
        Intent intent = new Intent(this, ServicebookActivity.class);
        startActivity(intent);
    }

        private void logout() {

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }


}